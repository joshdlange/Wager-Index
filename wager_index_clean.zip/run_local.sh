#!/bin/bash
export FLASK_APP=app/dashboard_app.py
flask run
