# Wager Index

Run `sh run_local.sh` to start.